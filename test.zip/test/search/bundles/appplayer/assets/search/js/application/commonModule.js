angular.module('sky', ['skySearch']);
