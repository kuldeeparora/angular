Sky = {};
Sky.Search = {
    app: angular.module('skySearch', ['ngSanitize']),
    url: "bundles/appplayer/assets/js/search/json/results.json",
    container: $('#searchResults'),
    searchInput: $("#searchInput")
};