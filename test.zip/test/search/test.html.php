<!DOCTYPE html>
<html xmlns:ng="http://angularjs.org" id="ng-app" ng-app="sky">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="stylesheet" type="text/css" href="bundles/appplayer/assets/search/css/style.css">
</head>

<body>
<header id="header" ng-cloak>
    <nav class="search">
            <ul class="menu">
                <li><span>Home</span></li>
                <li><span>New Releases</span></li>
                <li><span>Collections</span></li>
                <li><span>Genres</span></li>
                <li><span>Movie Channels</span></li>
                <li><span>News</span></li>
                <li><span>My Movies</span></li>
                <li>
                    <form>
                        <div class="search-test" ng-controller="SearchCtrl">
                            <input type="text" placeholder="Search..." autocomplete="off" id="searchInput"
                                   ng-model="searchTerm" ng-change="doSearch()" ng-blur="hideSearchResults()"
                                   sky-focus>
                            <div class="hide" ng-show="startedSearch && !isSearching" sky-unhide>
                                <ul id="searchResults" class="search-results">
                                    <li ng-repeat="item in searchResult | filter:searchTerm | limitTo:numberLimitTo"
                                        ng-show="searchTerm.length > 2">
                                        <div class="search-content">
                                        <a class="search-title clear-both" href="{{ item.slug }}"
                                              ng-bind-html="item.title | highlight:searchTerm"></a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </form>
                </li>
            </ul>
    </nav>
</header>

<script src="bundles/appplayer/assets/search/js/libs/jquery.min.js"></script>
<script src="bundles/appplayer/assets/search/js/libs/jquery-migrate.min.js"></script>
<script src="bundles/appplayer/assets/search/js/libs/angular.min.js"></script>
<script src="bundles/appplayer/assets/search/js/libs/angular-sanitize.min.js"></script>

<script src="bundles/appplayer/assets/search/js/application/boot.js"></script>
<script src="bundles/appplayer/assets/search/js/application/helper.js"></script>
<script src="bundles/appplayer/assets/search/js/application/filters.js"></script>
<script src="bundles/appplayer/assets/search/js/application/directives.js"></script>
<script src="bundles/appplayer/assets/search/js/application/controller.js"></script>
<script src="bundles/appplayer/assets/search/js/application/listeners.js"></script>
<script src="bundles/appplayer/assets/search/js/application/commonModule.js"></script>

</body>

</html>