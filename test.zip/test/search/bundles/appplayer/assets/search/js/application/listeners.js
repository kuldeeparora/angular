(function () {
    'use strict';

    // keyup & keydown
    $('.search-test').on("keydown", function (e) {
        if(Sky.Search.Helper.countVisibleResults() != 0){
            if (e.keyCode == 40) {
                if (Sky.Search.activeResultIndex === undefined) {
                    Sky.Search.activeResultIndex = 1;
                } else if ((Sky.Search.activeResultIndex + 1) < Sky.Search.Helper.countVisibleResults()) {
                    Sky.Search.activeResultIndex++;
                }
                $('.search-results li').removeClass('active');
                $('.search-results li:eq(' + Sky.Search.activeResultIndex + ')').addClass('active');
                return false;
            }
            if (e.keyCode == 38) {
                if (Sky.Search.activeResultIndex === undefined) {
                    Sky.Search.activeResultIndex = 0;
                } else if (Sky.Search.activeResultIndex > 0) {
                    Sky.Search.activeResultIndex--;
                }
                $('.search-results li').removeClass('active');
                $('.search-results li:eq(' + Sky.Search.activeResultIndex + ')').addClass('active');

                return false;
            }
        }
    });

    $(document).ready(function () {
        $("#search_input").focus(function(e) { $(this).select(); });
        $('#search_input').mouseup(function(e) { return false; });
    });

    $(document).mouseup(function (e) {
        if (Sky.Search.searchInput.length !== 0 && !Sky.Search.container.is(e.target) // if the target of the click isn't the container...
            && Sky.Search.container.has(e.target).length === 0
            && !Sky.Search.searchInput.is(e.target)) // ... nor a descendant of the container
        {
            Sky.Search.container.hide();
            Sky.Search.searchTerm = undefined;
            Sky.Search.searchInput.val("");
        }
    });
}());

