(function () {
    'use strict';

    Sky.Search.app.directive('skyUnhide', function(){
        return {
            link: function(scope, element, attrs, controller) {
                element.removeClass('hide').addClass('show');
            }
        };
    });

    Sky.Search.app.directive('skyFocus', function(){
        return {
            link: function(scope, element, attrs, controller) {
                element[0].focus();
                element[0].select();
            }
        };
    });
}());
