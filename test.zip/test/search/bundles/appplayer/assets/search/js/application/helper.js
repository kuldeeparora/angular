(function () {
    'use strict';
    Sky.Search.Helper = {
        countVisibleResults: function () {
            return $('.search-results').find('li').length;
        }
    };
}());
